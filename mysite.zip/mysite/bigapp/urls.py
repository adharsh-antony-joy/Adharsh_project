from django.contrib import admin
from django.urls import path
from .import views
urlpatterns=[
    path('reminder/',views.members,name='members'),
    path('',views.home_page,name='index'),
    path('about/',views.about,name='about'),
    path('register/',views.register)
]
