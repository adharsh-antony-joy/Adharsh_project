from django.shortcuts import render,redirect
from .models import *
from .forms import *
# Create your views here.
from django.http import HttpResponse
def members(request):
    return HttpResponse("hello")
def home_page(request):
    return render(request,'home.html')
def about(request):
    return render(request,'about.html')
def register(request):
    form=RegisterForm(request.POST,request.FILES)
    if request.method=='POST':
    #     u_name=request.POST['name']
    #     u_email=request.POST['email']
    #     password=request.POST['password']
    #     Register.objects.create_user(username=u_name,email=u_email,password=password,usertype='user')
       if request.method=='POST':

        if form.is_valid():
            form.save
            return redirect('/')
    return render(request,'register.html',{ 'form' : form})
def Login(request):
    if request.method=='POST':
        username=request.POST('username')
        password=request.POST('password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
    return render(request,'login.html')