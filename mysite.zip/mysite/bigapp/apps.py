from django.apps import AppConfig


class BigappConfig(AppConfig):
    name = 'bigapp'
